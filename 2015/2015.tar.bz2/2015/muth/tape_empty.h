#define tape ((,), _, (,))
